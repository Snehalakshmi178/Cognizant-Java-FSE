package com.library;

public class GreetingService {
    public void sayHello() {
        System.out.println("Spring is working");
        System.out.println("Hello from GreetingService.");
    }
}
